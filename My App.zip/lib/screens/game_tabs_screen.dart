import 'dart:async';
import 'package:flutter/material.dart';
import '../models/afl_fixture.dart';
import '../models/afl_player.dart';
import '../models/punter_selection.dart';
import '../repositories/fixture_repository.dart';
import '../repositories/player_repository.dart';
import '../widgets/punter_selection_table.dart';

class GameTabsScreen extends StatefulWidget {
  final int round;
  final FixtureRepository fixtureRepo;
  final PlayerRepository playerRepo;
  final int punterCount;
  final Future<void> Function() refreshFantasyScores;

  const GameTabsScreen({
    super.key,
    required this.round,
    required this.fixtureRepo,
    required this.playerRepo,
    required this.punterCount,
    required this.refreshFantasyScores,
  });

  @override
  State<GameTabsScreen> createState() => _GameTabsScreenState();
}

class _GameTabsScreenState extends State<GameTabsScreen> {
  late List<PunterSelection> thursdaySelections;
  late List<PunterSelection> fridaySelections;
  late List<PunterSelection> saturdaySelections;
  late List<PunterSelection> sundaySelections;
  late List<PunterSelection> mondaySelections;
  late List<PunterSelection> weekendQuadSelections;

  Timer? _autoRefreshTimer;

  @override
  void initState() {
    super.initState();

    thursdaySelections = _createSelections(2);
    fridaySelections = _createSelections(2);
    saturdaySelections = _createSelections(2);
    sundaySelections = _createSelections(2);
    mondaySelections = _createSelections(2);
    weekendQuadSelections = _createSelections(4);

    // 🔄 Auto-refresh fantasy scores every 5 seconds
    _autoRefreshTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => widget.refreshFantasyScores(),
    );
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    super.dispose();
  }

  List<PunterSelection> _createSelections(int playersPerPunter) {
    return List.generate(
      widget.punterCount,
      (_) => PunterSelection(playersPerPunter),
    );
  }

  List<AflFixture> _fixturesForWeekday(int weekday) {
    return widget.fixtureRepo.fixtures.where((f) {
      final d = f.date;
      return f.round == widget.round && d != null && d.weekday == weekday;
    }).toList();
  }

  List<AflFixture> _fixturesForWeekendQuads() {
    return widget.fixtureRepo.fixtures.where((f) {
      if (f.round != widget.round) return false;
      final d = f.date;
      if (d == null) return true; // include TBA fixtures
      return d.weekday == DateTime.friday ||
          d.weekday == DateTime.saturday ||
          d.weekday == DateTime.sunday ||
          d.weekday == DateTime.monday;
    }).toList();
  }

  List<AflPlayer> _playersForFixtures(List<AflFixture> fixtures) {
    final clubs = <String>{
      for (final f in fixtures) f.homeTeam,
      for (final f in fixtures) f.awayTeam,
    };

    return widget.playerRepo.players
        .where((p) => clubs.contains(p.club))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("AFL Pairs"),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: "Thursday Pairs"),
              Tab(text: "Friday Pairs"),
              Tab(text: "Saturday Pairs"),
              Tab(text: "Sunday Pairs"),
              Tab(text: "Monday Pairs"),
              Tab(text: "Weekend Quads"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTabContent(
              fixtures: _fixturesForWeekday(DateTime.thursday),
              selections: thursdaySelections,
              playersPerPunter: 2,
            ),
            _buildTabContent(
              fixtures: _fixturesForWeekday(DateTime.friday),
              selections: fridaySelections,
              playersPerPunter: 2,
            ),
            _buildTabContent(
              fixtures: _fixturesForWeekday(DateTime.saturday),
              selections: saturdaySelections,
              playersPerPunter: 2,
            ),
            _buildTabContent(
              fixtures: _fixturesForWeekday(DateTime.sunday),
              selections: sundaySelections,
              playersPerPunter: 2,
            ),
            _buildTabContent(
              fixtures: _fixturesForWeekday(DateTime.monday),
              selections: mondaySelections,
              playersPerPunter: 2,
            ),
            _buildTabContent(
              fixtures: _fixturesForWeekendQuads(),
              selections: weekendQuadSelections,
              playersPerPunter: 4,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent({
    required List<AflFixture> fixtures,
    required List<PunterSelection> selections,
    required int playersPerPunter,
  }) {
    final players = _playersForFixtures(fixtures);

    return Column(
      children: [
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: widget.refreshFantasyScores,
          child: const Text("Refresh Fantasy Scores"),
        ),
        const SizedBox(height: 12),
        _buildFixtureTable(fixtures),
        Expanded(
          child: PunterSelectionTable(
            punterCount: widget.punterCount,
            playersPerPunter: playersPerPunter,
            availablePlayers: players,
            selections: selections,
            onChanged: () => setState(() {}),
          ),
        ),
      ],
    );
  }

  Widget _buildFixtureTable(List<AflFixture> fixtures) {
    if (fixtures.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          "No fixtures found.",
          style: TextStyle(fontSize: 16),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Table(
        border: TableBorder.all(color: Colors.grey),
        columnWidths: const {
          0: FlexColumnWidth(2),
          1: FlexColumnWidth(2),
          2: FlexColumnWidth(2),
          3: FlexColumnWidth(3),
        },
        children: [
          const TableRow(
            decoration: BoxDecoration(color: Color(0xFFE0E0E0)),
            children: [
              Padding(
                padding: EdgeInsets.all(8),
                child: Text("Date", style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: Text("Home", style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: Text("Away", style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: Text("Venue", style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          ...fixtures.map(
            (f) => TableRow(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(f.date?.toLocal().toString().split(' ')[0] ?? "TBA"),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(f.homeTeam),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(f.awayTeam),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(f.venue),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}