@JS()
library msal_web;

import 'dart:async';
import 'package:js/js.dart';
import 'package:js/js_util.dart' as js_util;

/// ------------------------------------------------------------
/// MSAL Public Client Application
/// ------------------------------------------------------------
@JS('msal.PublicClientApplication')
class PublicClientApplication {
  external PublicClientApplication(dynamic config);

  /// Returns a JS Promise<AuthenticationResult>
  external dynamic loginPopup(dynamic request);

  /// Returns a JS Promise<AuthenticationResult>
  external dynamic acquireTokenSilent(dynamic request);

  /// Synchronous array of JS account objects
  external List<dynamic> getAllAccounts();
}

/// ------------------------------------------------------------
/// MSAL Config Objects
/// ------------------------------------------------------------
@JS()
@anonymous
class MsalConfig {
  external factory MsalConfig({
    required dynamic auth,
    required dynamic cache,
  });
}

@JS()
@anonymous
class AuthConfig {
  external factory AuthConfig({
    required String clientId,
    required String authority,
    required String redirectUri,
  });
}

@JS()
@anonymous
class CacheConfig {
  external factory CacheConfig({
    required String cacheLocation,
    required bool storeAuthStateInCookie,
  });
}

@JS()
@anonymous
class LoginRequest {
  external factory LoginRequest({
    required List<String> scopes,
  });
}

@JS()
@anonymous
class SilentRequest {
  external factory SilentRequest({
    required List<String> scopes,
    required dynamic account,
  });
}

/// ------------------------------------------------------------
/// Typed JS interop for MSAL responses
/// (AuthenticationResult in MSAL terms)
/// ------------------------------------------------------------
@JS()
@anonymous
class AuthenticationResult {
  external dynamic get account;
  external String get accessToken;
  external List<String> get scopes;
  external String get idToken;
  external dynamic get idTokenClaims;
}

/// ------------------------------------------------------------
/// Global MSAL instance + active account
/// ------------------------------------------------------------
late PublicClientApplication _msalInstance;
dynamic _activeAccount;

/// ------------------------------------------------------------
/// INITIALIZE MSAL WITH PERSISTENT LOGIN
/// ------------------------------------------------------------
void initMsal() {
  final config = MsalConfig(
    auth: AuthConfig(
      clientId: "c75121a5-552e-46c6-a357-2e5029b56131",
      authority: "https://login.microsoftonline.com/common",
      redirectUri: "http://localhost:57777",
    ),
    cache: CacheConfig(
      cacheLocation: "localStorage",
      storeAuthStateInCookie: true,
    ),
  );

  _msalInstance = PublicClientApplication(config);

  // Restore active account after refresh
  final accounts = _msalInstance.getAllAccounts();
  if (accounts.isNotEmpty) {
    _activeAccount = accounts[0];
  }
}

/// ------------------------------------------------------------
/// ACQUIRE TOKEN WITH SILENT FALLBACK
/// ------------------------------------------------------------
///
/// Call this from Dart/Flutter to ensure the user is authenticated:
///   final token = await acquireTokenWithMsal(['User.Read']);
///   if (token != null) { ... }
///
Future<String?> acquireTokenWithMsal(List<String> scopes) async {
  // 1. Try silent first if we have an account
  try {
    if (_activeAccount != null) {
      final silentPromise = _msalInstance.acquireTokenSilent(
        SilentRequest(
          scopes: scopes,
          account: _activeAccount,
        ),
      );

      final silentResult =
          await js_util.promiseToFuture<AuthenticationResult>(silentPromise);

      if (silentResult.accessToken.isNotEmpty) {
        return silentResult.accessToken;
      }
    }
  } catch (_) {
    // Silent failed → we'll fall back to popup
  }

  // 2. Popup login as fallback
  final popupPromise = _msalInstance.loginPopup(
    LoginRequest(scopes: scopes),
  );

  final popupResult =
      await js_util.promiseToFuture<AuthenticationResult>(popupPromise);

  if (popupResult.accessToken.isNotEmpty) {
    _activeAccount = popupResult.account;
    return popupResult.accessToken;
  }

  return null;
}