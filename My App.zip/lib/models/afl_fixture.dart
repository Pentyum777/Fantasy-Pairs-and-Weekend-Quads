class AflFixture {
  final String roundLabel;
  final int round;

  /// Nullable because some fixtures are TBA/TBD/TBC
  final DateTime? date;

  final String homeTeam;
  final String awayTeam;
  final String venue;
  final String time;
  final String source;

  AflFixture({
    required this.roundLabel,
    required this.round,
    required this.date,      // now nullable
    required this.homeTeam,
    required this.awayTeam,
    required this.venue,
    required this.time,
    required this.source,
  });
}