import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'msal_web.dart';
import 'repositories/player_repository.dart';
import 'repositories/fixture_repository.dart';
import 'widgets/round_selector.dart';
import 'services/fantasy_score_service.dart';
import 'screens/game_tabs_screen.dart';

void main() {
  initMsal();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  bool isLoggedIn = false;
  bool isLoadingPlayers = false;

  late final PlayerRepository playerRepo;
  late final FixtureRepository fixtureRepo;
  final FantasyScoreService fantasyService = FantasyScoreService();

  int punterCount = 11;
  int? selectedRound;

  @override
  void initState() {
    super.initState();
    playerRepo = PlayerRepository();
    fixtureRepo = FixtureRepository();
  }

  void showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _handleLogin() async {
    final token = await acquireTokenWithMsal([
      "User.Read",
      "Files.Read",
      "Files.Read.All",
    ]);

    if (!mounted) return;

    if (token == null) {
      showMessage("Login failed. Please try again.");
      return;
    }

    setState(() {
      isLoggedIn = true;
      isLoadingPlayers = true;
    });

    try {
      final playerBytes = await rootBundle.load("assets/afl_players_2026.xlsx");
      final fixtureBytes =
          await rootBundle.load("assets/afl_fixtures_2026.xlsx");

      if (!mounted) return;

      playerRepo.loadFromExcel(playerBytes.buffer.asUint8List());
      fixtureRepo.loadFromExcel(fixtureBytes.buffer.asUint8List());
    } catch (e) {
      if (!mounted) return;
      showMessage("Error loading assets: $e");
    }

    if (!mounted) return;

    setState(() {
      isLoadingPlayers = false;
    });
  }

  Future<void> _refreshFantasyScores() async {
    final round = selectedRound;
    if (round == null) return;

    final fixtures = fixtureRepo.fixturesForRound(round);
    final urls = fixtures.map((f) => f.source).where((u) => u.isNotEmpty);

    final allScores = <String, int>{};

    for (final url in urls) {
      final scores = await fantasyService.fetchScores(url);
      allScores.addAll(scores);
    }

    if (!mounted) return;

    playerRepo.applyFantasyScores(allScores);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      scaffoldMessengerKey: scaffoldMessengerKey,
      title: "AFL Pairs",
      home: Builder(
        builder: (context) {
          return Scaffold(
            appBar: AppBar(
              title: const Text("AFL Pairs"),
            ),
            body: _buildBody(context),
          );
        },
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (!isLoggedIn) {
      return Center(
        child: ElevatedButton(
          onPressed: _handleLogin,
          child: const Text("Login with Microsoft"),
        ),
      );
    }

    if (isLoadingPlayers) {
      return const Center(child: CircularProgressIndicator());
    }

    if (selectedRound == null) {
      final rounds = fixtureRepo.fixtures
          .map((f) => f.round)
          .toSet()
          .toList()
        ..sort();

      return RoundSelector(
        rounds: rounds,
        onSelect: (round) {
          setState(() => selectedRound = round);

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => GameTabsScreen(
                round: round,
                fixtureRepo: fixtureRepo,
                playerRepo: playerRepo,
                punterCount: punterCount,
                refreshFantasyScores: _refreshFantasyScores,
              ),
            ),
          ).then((_) {
            setState(() => selectedRound = null);
          });
        },
      );
    }

    return const Center(
      child: Text(
        "Loading tabs...",
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}